/* Hello World program */

#include <stdio.h>
#include <stdlib.h>

int
main ()
{
  printf ("Hello World\n");
  return EXIT_SUCCESS;
}
